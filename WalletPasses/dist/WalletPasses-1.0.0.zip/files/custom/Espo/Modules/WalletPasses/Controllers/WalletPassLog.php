<?php

declare(strict_types=1);

namespace Espo\Modules\WalletPasses\Controllers;

use Espo\Core\Controllers\Record;

class WalletPassLog extends Record
{
}
